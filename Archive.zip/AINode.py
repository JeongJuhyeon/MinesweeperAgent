class aiNode:
    def __init__(self, pos):
        self.pos = pos
        self.cant_be_mine = False
        self.definitely_mine = False